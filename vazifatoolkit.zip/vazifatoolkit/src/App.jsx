import React, { useRef } from 'react';
import './App.css';
import { useSelector, useDispatch } from 'react-redux';
import { increment, decrement, incrementByAmount } from './features/counter/counterClice'

function App() {
  const { value } = useSelector((state) => state.counter);
  const dispatch = useDispatch();
  const inputVal = useRef();

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(incrementByAmount(+inputVal.current.value));
  }

  return (
    <>
      <h1>{value}</h1>
      <button onClick={() => dispatch(increment())}>Qoshuvchi</button>
      <button onClick={() => dispatch(decrement())}>Ayiruvchi</button>
      <form onSubmit={handleSubmit}>
        <input ref={inputVal} type="text" />
        <button>Add</button>
      </form>
    </>
  );
}

export default App;